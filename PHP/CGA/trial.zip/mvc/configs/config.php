<?php

//Database params
define('DB_HOST', 'localhost:3306');  //Add your db host
define('DB_USER', 'root'); // Add your DB root
define('DB_PASS', 'root.SQL'); //Add your 
define('DB_NAME', 'cga'); //Add your DB Name

//APPROOT
define('APPROOT', dirname(dirname(__FILE__)));

//URLROOT (Dynamic links)
define('URLROOT', 'http://localhost/CGA/fresh/');

//Sitename
define('SITENAME', 'CGA');