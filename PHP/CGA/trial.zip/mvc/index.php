<?php
require('helpers/require.php');

// Check if the user is logged in, if not then redirect him to login page
if (!isLoggedIn()) {
    header("location: ./views/auth/login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles/style.css">
    <title>Welcome</title>
</head>

<body>

    <header>
        <h1>Welcome to CGA</h1>
        <nav>
            <p>Logged in as <b>User</b></p>
            <ul>
                <li><a href="#">Change Email</a></li>
                <li><a href="#">Change Password</a></li>
                <li><a href="./views/auth/logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>

        <Section>
            <div class="role-body">
                <p>Select available role</p>

                <div class="role-list">
                    <a href="./users/admin.php">Admin</a>
                    <a href="./users/Professor.php">Professor</a>
                    <a href="./users/ta.php">Teaching Assistant</a>
                    <a href="./users/student.php">Student</a>
                </div>

            </div>
        </Section>

    </main>

</body>

</html>