<?php

//Required files
require_once("session.php");
require_once("controllers/Database.php");
require_once("controllers/Functions.php");
