<footer>
    <p> (c) CrsMgr Group-work Assistant (CGA) | Comp5531/Group_4 Winter/Spring 2022</p>
</footer>

</body>

</html>