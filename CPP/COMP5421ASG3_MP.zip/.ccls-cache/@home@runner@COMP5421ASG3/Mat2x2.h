// COMP5421 - Asg3 - Summer 2022
// Mike Poullas - 21917739
// Dictionary.cpp

#ifndef Quad_h
#define Quad_h

#include <stdio.h>
#include <array>
#include <iostream>

using std::array;
using std::initializer_list;
using std::ostream;
using std::istream;

class Quad {
private:
    double a; // top-left
    double b; // top-right
    double c; // bottom-left
    double d; // bottom-right
public:
    // BIG FIVE
    explicit Quad(double = 0, double = 0, double = 0, double = 0);
    Quad(const array<double, 4> &);          // using std::array;
    Quad(const array<array<double, 2>, 2>&); // using std::array;
    Quad(const initializer_list<double>);    // using std::initializer_list;
    Quad(const Quad&) = default; // default copy constructor
    Quad(Quad&&) = default; // default move constructor
    Quad& operator=(const Quad&) = default; // default copy assignment operator
    Quad& operator=(Quad&&) = default; // default move assignment operator
    ~Quad() = default; // default destructor
    
    // SOME FUNCTIONS
    double norm() const; // returns the norm of the calling object
    Quad inverse() const; // returns the inverse of the calling object
    double det() const; // returns the determinant of the calling object
    
    // MEMBER OPERATOR OVERLOADING
    Quad& operator+=(const Quad&); // addition assignment operator overloading
    Quad& operator-=(const Quad&); // substraction assignment operator overloading
    Quad& operator*=(const Quad&); // multiplication assignment operator overloading
    Quad& operator/=(const Quad&); // division assignment operator overloading
    
    Quad& operator+=(const double&); // addition assignment operator overloading
    Quad& operator-=(const double&); // substraction assignment operator overloading
    Quad& operator*=(const double&); // multiplication assignment operator overloading
    Quad& operator/=(const double&); // division assignment operator overload
    
    Quad& operator++(); // prefix increment operator overloading
    const Quad operator++(int); // postfix increment operator overloading
    Quad& operator--(); // prefix decrement operator overloading
    const Quad operator--(int); // postfix decrement operator overloading
    Quad operator+(); // unary plus operator overloading
    Quad operator-(); // unary minus operator overloading
    
    Quad operator^(int k); // XOR operator overloading; returns the Quad object resulting from raising it to the power k
    
    const double& operator[](size_t) const; // returns an element of the matrix found at a specific index
    double& operator[](size_t); // returns an element of the matrix found at a specific index
    
    explicit operator bool() const; // returns whether or not the invoking object has inverse
    
    // FUNCTION OBJECTS
    double operator()() const; // returns the norm of the invoking Quad object
    double& operator()(size_t r, size_t c); // returns an lvalue reference to the entry at row r and column c
    
    // STATIC MEMBERS
    static double tolerance; // initial value = 1.0E-6
    static void setTolerance(double tol);
    static double getTolerance();
};

// NON-MEMBER OPERATOR OVERLOADING
ostream& operator<<(ostream&, const Quad&); // insertion operator overloading
istream& operator>>(istream&, Quad&); // extraction operator overloading

Quad operator+(const Quad&, const Quad&); // addition operator overloading
Quad operator-(const Quad&, const Quad&); // substraction operator overloading
Quad operator*(const Quad&, const Quad&); // multiplication operator overloading
Quad operator/(const Quad&, const Quad&); // division operator overloading

Quad operator+(const Quad&, const double&); // addition operator overloading
Quad operator-(const Quad&, const double&); // substraction operator overloading
Quad operator*(const Quad&, const double&); // multiplication operator overloading
Quad operator/(const Quad&, const double&); // division operator overloading

Quad operator+(const double&, const Quad&); // addition operator overloading
Quad operator-(const double&, const Quad&); // substraction operator overloading
Quad operator*(const double&, const Quad&); // multiplication operator overloading
Quad operator/(const double&, const Quad&); // division operator overloading

bool operator<(const Quad&, const Quad&); // less than operator overloading
bool operator<=(const Quad&, const Quad&); // less than or equal to operator overloading
bool operator>(const Quad&, const Quad&); // greater than operator overloading
bool operator>=(const Quad&, const Quad&); // greater than or equal operator overloading
bool operator==(const Quad&, const Quad&); // equal to operator overloading
bool operator!=(const Quad&, const Quad&); // not equal to operator overloading

#endif /* Quad_hpp */
