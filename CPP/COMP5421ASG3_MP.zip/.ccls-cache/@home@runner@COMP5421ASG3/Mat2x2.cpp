// COMP5421 - Asg3 - Summer 2022
// Mike Poullas - 21917739
// Dictionary.cpp

#include <iostream>
#include <iomanip>
#include <cmath>
#include "Quad.h"

// BIG FIVE
Quad::Quad(double a, double b, double c, double d): a{a}, b{b}, c{c}, d{d} {};
Quad::Quad(const array<double, 4> & y): a{y[0]}, b{y[1]}, c{y[2]}, d{y[3]} {}; // using std::array;
Quad::Quad(const array<array<double, 2>, 2>& x): a{x[0][0]}, b{x[0][1]}, c{x[1][0]}, d{x[1][1]} {}; // using std::array;
Quad::Quad(const initializer_list<double> l) { // using std::initializer_list;
    std::initializer_list<double>::iterator it = l.begin();
    if (l.size() > 0) a = *it++;
    else a = b = c = d = 0;
    if (l.size() > 1) b = *it++;
    else b = c = d = 0;
    if (l.size() > 2) c = *it++;
    else c = d = 0;
    if (l.size() > 3) d = *it++;
    else d = 0;
};

// SOME FUNCTIONS
double Quad::norm() const {return sqrt(a*a+b*b+c*c+d*d);}; // returns the norm of the calling object
Quad Quad::inverse() const {return (1/det()) * Quad(d, -b, -c, a);}; // returns the inverse of the calling object
double Quad::det() const {return a * d - b * c;}; // returns the determinant of the calling object

// MEMBER OPERATOR OVERLOADING
Quad& Quad::operator+=(const Quad& rhs) { // addition assignment operator overloading
    a = a + rhs.a;
    b = b + rhs.b;
    c = c + rhs.c;
    d = d + rhs.d;
    return *this;
};
Quad& Quad::operator-=(const Quad& rhs) { // substraction assignment operator overloading
    a = a - rhs.a;
    b = b - rhs.b;
    c = c - rhs.c;
    d = d - rhs.d;
    return *this;
};
Quad& Quad::operator*=(const Quad& rhs) { // multiplication assignment operator overloading
    double new_a = a * rhs.a + b * rhs.c;
    double new_b = a * rhs.b + b * rhs.d;
    double new_c = rhs.a * c + rhs.c * d;
    double new_d = rhs.b * c + d * rhs.d;
    a = new_a;
    b = new_b;
    c = new_c;
    d = new_d;
    return *this;
};
Quad& Quad::operator/=(const Quad& rhs) { // division assignment operator overloading
    *this *= rhs.inverse();
    return *this;
};
Quad& Quad::operator+=(const double& rhs) { // addition assignment operator overloading
    a = a + rhs;
    b = b + rhs;
    c = c + rhs;
    d = d + rhs;
    return *this;
};
Quad& Quad::operator-=(const double& rhs) { // substraction assignment operator overloading
    *this = -(rhs - *this);
    return *this;
};
Quad& Quad::operator*=(const double& rhs) { // multiplication assignment operator overloading
    a = a * rhs;
    b = b * rhs;
    c = c * rhs;
    d = d * rhs;
    return *this;
};
Quad& Quad::operator/=(const double& rhs) { // division assignment operator overload
    if (rhs == 0)
        throw std::runtime_error("Math error: Attempted to divide by Zero\n");
    a = a * (1.0 / rhs);
    b = b * (1.0 / rhs);
    c = c * (1.0 / rhs);
    d = d * (1.0 / rhs);
    return *this;
};
Quad& Quad::operator++() { // prefix increment operator overloading
    *this += 1.0;
    return *this;
};
const Quad Quad::operator++(int) { // postfix increment operator overloading
    Quad temp {*this};
    ++(*this);
    return temp;
};
Quad& Quad::operator--() { // prefix decrement operator overloading
    *this -= 1.0;
    return *this;
};
const Quad Quad::operator--(int) { // postfix decrement operator overloading
    Quad temp {*this};
    --(*this);
    return temp;
};
Quad Quad::operator+() { // unary plus operator overloading
    return Quad{abs(a), abs(b), abs(c), abs(d)};
};
Quad Quad::operator-() { // unary minus operator overloading
    Quad temp{*this};
    temp *= -1.0;
    return temp;
};

Quad Quad::operator^(int k) { // XOR operator overloading; returns the Quad object resulting from raising it to the power k
    Quad temp;
    if (k < 0) temp = inverse();
    else temp = *this;
    for (int i = 1; i < abs(k); ++i)
        if (k < 0) temp *= inverse();
        else temp *= *this;
    return temp;
};
const double& Quad::operator[](size_t index) const { // returns an element of the matrix found at a specific index
    if (index == 0) return a;
    else if (index == 1) return b;
    else if (index == 2) return c;
    else if (index == 3) return d;
    else throw std::invalid_argument("index out of bounds");
};
double& Quad::operator[](size_t index) { // returns an element of the matrix found at a specific index
    if (index == 0) return a;
    else if (index == 1) return b;
    else if (index == 2) return c;
    else if (index == 3) return d;
    else throw std::invalid_argument("index out of bounds");
};

Quad::operator bool() const { // returns whether or not the invoking object has inverse
    if (abs(det()) > tolerance) return true;
    else return false;
};

// FUNCTION OBJECTS
double Quad::operator()() const {return norm();} // returns the norm of the invoking Quad object
double& Quad::operator()(size_t r, size_t c) {  // returns an lvalue reference to the entry at row r and column c
    if (r < 1 || r > 2) throw std::invalid_argument("row index out of bounds");
    if (c < 1 || c > 2) throw std::invalid_argument("column index out of bounds");
    if (r == 1)
        if (c == 1) return a;
        else return b;
    else
        if (c == 1) return this->c;
        else return d;
};

// STATIC MEMBERS
double Quad::tolerance = 0.000001;
void Quad::setTolerance(double tol) {tolerance = tol;};
double Quad::getTolerance() {return tolerance;};

// NON-MEMBER OPERATOR OVERLOADING
ostream& operator<<(ostream& sout, const Quad& m) { // insertion operator overloading
    sout << std::fixed << std::setprecision(2) << "[" << m[0] << ", " << m[1] << ", " << m[2] << ", " << m[3] << "]";
    return sout;
};
istream& operator>>(istream& sin, Quad& m) { // extraction operator overloading
    double a, b, c, d;
    if (sin >> a >> b >> c >> d) {
        m[0] = a;
        m[1] = b;
        m[2] = c;
        m[3] = d;
    }
    return sin;
};

Quad operator+(const Quad& lhs, const Quad& rhs) { // addition operator overloading
    Quad temp {lhs};
    temp += rhs;
    return temp;
};
Quad operator-(const Quad& lhs, const Quad& rhs) { // substraction operator overloading
    Quad temp {lhs};
    temp -= rhs;
    return temp;
};
Quad operator*(const Quad& lhs, const Quad& rhs) { // multiplication operator overloading
    Quad temp {lhs};
    temp *= rhs;
    return temp;
};
Quad operator/(const Quad& lhs, const Quad& rhs) { // division operator overloading
    Quad temp {lhs};
    temp /= rhs;
    return temp;
};

Quad operator+(const Quad& lhs, const double& rhs) { // addition operator overloading
    Quad temp {lhs};
    temp += rhs;
    return temp;
};
Quad operator-(const Quad& lhs, const double& rhs) { // substraction operator overloading
    Quad temp {lhs};
    temp -= rhs;
    return temp;
};
Quad operator*(const Quad& lhs, const double& rhs) { // multiplication operator overloading
    Quad temp {lhs};
    temp *= rhs;
    return temp;
};
Quad operator/(const Quad& lhs, const double& rhs) { // division operator overloading
    Quad temp {lhs};
    temp /= rhs;
    return temp;
};

Quad operator+(const double& lhs, const Quad& rhs) { // addition operator overloading
    Quad temp {rhs};
    temp += lhs;
    return temp;
};
Quad operator-(const double& lhs, const Quad& rhs) { // substraction operator overloading
    Quad temp {lhs-rhs[0], lhs-rhs[1], lhs-rhs[2], lhs-rhs[3]};
    return temp;
};
Quad operator*(const double& lhs, const Quad& rhs) { // multiplication operator overloading
    Quad temp {rhs};
    temp *= lhs;
    return temp;
};
Quad operator/(const double& lhs, const Quad& rhs) { // division operator overloading
    Quad temp {rhs.inverse()};
    temp *= lhs;
    return temp;
};

bool operator<(const Quad& lhs, const Quad& rhs) { // less than operator overloading
    if (operator!=(lhs, rhs) && lhs.norm() < rhs.norm()) return 1;
    else return 0;
};
bool operator<=(const Quad& lhs, const Quad& rhs) { // less than or equal to operator overloading
    return operator<(lhs, rhs) || operator==(lhs, rhs);
};
bool operator>(const Quad& lhs, const Quad& rhs) { // greater than operator overloading
    if (operator!=(lhs, rhs) && lhs.norm() > rhs.norm()) return 1;
    else return 0;
};
bool operator>=(const Quad& lhs, const Quad& rhs) { // greater than or equal operator overloading
    return operator>(lhs, rhs) || operator==(lhs, rhs);
};
bool operator==(const Quad& lhs, const Quad& rhs) { // equal to operator overloading
    Quad temp = lhs - rhs;
    if (temp.norm() <= Quad::getTolerance()) return 1;
    else return 0;
};
bool operator!=(const Quad& lhs, const Quad& rhs) { // not equal to operator overloading
    return !operator==(lhs, rhs);
};
